%% Enhanced Orchard Navigation System with Pure Pursuit Segmented and Genetic Algorithm
% Integrates bicycle model dynamics, EKF state estimation, tree detection,
% pure pursuit segmented controller, and genetic algorithm for optimal path planning
clear; close all; clc;
% Create results directory
[~, ~] = mkdir("results");

%% ----- Generate orchard environment (ground truth - not accessible to robot) -----
global bitmap;
R = 5000; C = 5000; % Grid resolution
bitmap = zeros(R, C);
K = 5; % Number of tree rows
M = 7; % Maximum trees per row
W = 3; % Distance between tree rows (m)
D = 2; % Distance between trees in same row (m)
Xmax = W*(K-1)+30; 
Ymax = Xmax;
gridResolution = Xmax/R;

% Generate orchard layout
x = zeros(M, K); 
y = zeros(M, K);
maxTreeRadius = 0.5;
minTreeRadius = 0.2;
x(1,1) = 20-W/2; 
y(1,1) = 20;
j = 1;
while (j <= K)
    for i = 2:M
        y(i,j) = y(i-1,j) + D;
        x(i,j) = x(i-1,j);
    end
    j = j+1;
    if j <= K
        x(1,j) = x(1,j-1) + W; 
        y(1,j) = 20;
    end
end

% Place trees with random radii and store ground truth
ground_truth_trees = [];
tree_block_bounds = struct(); % Store tree block boundaries
for j = 1:K
    for i = 1:M
        radius = (minTreeRadius + rand*(maxTreeRadius-minTreeRadius))/(Xmax/C);
        [I, J] = XYtoIJ(x(i,j), y(i,j), Xmax, Ymax, R, C);
        if rand > 0.02
            draw_disc(I, J, radius, R, C);
            % Store ground truth: [x, y, diameter]
            diameter_m = radius * (Xmax/C) * 2; % Convert to meters
            ground_truth_trees(end+1, :) = [x(i,j), y(i,j), diameter_m];
        end
    end
end

% Calculate tree block boundaries
if ~isempty(ground_truth_trees)
    tree_block_bounds.xmin = min(ground_truth_trees(:,1)) - 2;
    tree_block_bounds.xmax = max(ground_truth_trees(:,1)) + 2;
    tree_block_bounds.ymin = min(ground_truth_trees(:,2)) - 2;
    tree_block_bounds.ymax = max(ground_truth_trees(:,2)) + 2;
else
    % Default bounds if no trees
    tree_block_bounds.xmin = 15; tree_block_bounds.xmax = 25;
    tree_block_bounds.ymin = 15; tree_block_bounds.ymax = 30;
end

fprintf('Generated orchard with %d trees\n', size(ground_truth_trees, 1));
fprintf('Tree block bounds: X[%.1f, %.1f], Y[%.1f, %.1f]\n', ...
    tree_block_bounds.xmin, tree_block_bounds.xmax, ...
    tree_block_bounds.ymin, tree_block_bounds.ymax);
save('results/ground_truth_trees.mat', 'ground_truth_trees');

%% ----- Initialize all parameters -----
% Vehicle parameters (Ackermann-steered vehicle)
L = 3;                      % wheelbase, 3 meters
W_vehicle = 2;              % width of the vehicle, 2 meters
gamma_limit = deg2rad(55);  % steering limit, 55 deg
tau_gamma = 0.1;            % steering lag, 0.1 sec
tau_v = 0.1;                % velocity lag, 0.1 sec
v_ref = 2;                  % reference speed, 2 m/s

% Pure Pursuit Segmented Controller parameters
Ld_line = 4.0;              % lookahead distance for straight segments
Ld_turn = 2.0;              % lookahead distance for turn segments
Rmin = L / tan(gamma_limit); % minimum turning radius

% Control limits
umin = [-gamma_limit; 0];   % [steering; velocity] lower bounds
umax = [gamma_limit; 5];    % [steering; velocity] upper bounds
Qmin = [-inf; -inf; -inf; -gamma_limit; 0];  % state lower bounds
Qmax = [inf; inf; inf; gamma_limit; 5];      % state upper bounds

% Initial state [x, y, theta, gamma, v] - Start at (0,0) facing 90° North
q_init = [0; 0; pi/2; 0; 0];  % Start at (0,0) facing North (90°), zero initial velocity

% Time parameters
global dt DT
dt = 0.001;     % inner integration step, 1 ms
DT = 0.01;      % controller period, 10 ms
Tsim = 300;     % increased simulation time for complete navigation
steps = 0:DT:Tsim;
Nsteps = numel(steps);

% LiDAR parameters
global angleSpan angleStep rangeMax
angleSpan = deg2rad(180);       % 180 degree field of view
angleStep = deg2rad(0.125);     % 0.125 degree resolution
rangeMax = 20;                  % 20 meter range
lidar_angles = linspace(-pi/2, pi/2, 181); % 180-degree FOV, 1-degree resolution
num_beams = length(lidar_angles);

% Occupancy grid parameters
map_R = 2000; map_C = 2000;  % Use 2000x2000 as compromise
logOdds = zeros(map_R, map_C);
p_occ = 0.7;                % Probability of occupancy for hits
p_free = 0.3;               % Probability of free space

%% ==== TASK 1: ESTIMATE SENSOR COVARIANCES ====
fprintf('\n=== TASK 1: Estimating sensor covariances ===\n');
[Q_odo_estimated, R_gps_estimated] = estimateSensorCovariances(q_init, L, tau_gamma, tau_v, ...
    umin, umax, Qmin, Qmax, bitmap, Xmax, Ymax);

%% ==== TASK 2: IMPLEMENT EKF WITH MEDIAN FILTER ====
fprintf('\n=== TASK 2: Implementing EKF with filtered sensors ===\n');
% EKF initialization - Start at (0,0) facing North
x_est = [0; 0; pi/2];           % [x; y; theta] - start at (0,0) facing North (90°)
P = eye(3) * 0.01;              % Small initial uncertainty
Q_odo = Q_odo_estimated;        % Use estimated covariances
R_gps = R_gps_estimated;
H = eye(3);                     % Measurement matrix

% Median filter parameters for laser
median_window_size = 5;

%% Visualization setup
figure(1);
set(gcf, 'Position', [50, 50, 1400, 600]);

subplot(1,2,1);
x_im = [0 Xmax]; y_im = [0 Ymax];
imagesc(x_im, y_im, flip(bitmap));
set(gca,'YDir','normal');
axis equal;
title('Ground Truth Environment');
xlabel('X (m)'); ylabel('Y (m)');
colormap(gca, 'gray');

subplot(1,2,2);
h_map = imagesc(x_im, y_im, flip(logOddsToProbability(logOdds)));
set(gca,'YDir','normal');
axis equal;
title('Built Occupancy Grid');
xlabel('X (m)'); ylabel('Y (m)');
colormap(gca, 'hot');
caxis([0 1]);
colorbar;

%% ==== NAVIGATION STRATEGY ====
fprintf('\n=== NAVIGATION WITH PURE PURSUIT ===\n');

% PHASE 1: Initial perimeter scan to identify tree block
fprintf('\n--- Phase 1: Perimeter scan to identify tree block ---\n');
perimeter_trajectory = planPerimeterScanTrajectory(Xmax, Ymax);

% PHASE 2: Analyze detected tree block and plan column traversal  
fprintf('\n--- Phase 2: Analyzing tree block and planning traversal ---\n');

% Data storage for entire navigation
q_hist = [];
x_est_hist = [];
path_x = []; path_y = [];
scan_count = 0;
step_count = 0;
q_true = q_init;
gps_idx = 0;

%% PHASE 1 EXECUTION: Perimeter scan
fprintf('\nExecuting Phase 1: Perimeter Scan\n');
fprintf('Phase 1 Terminal Condition: Detect the most northeastern trees in the block\n');
current_phase = 1;
[q_true, x_est, P, logOdds, path_x, path_y, scan_count, step_count, gps_idx, phase1_terminated] = ...
    executeTrajectoryWithSimplePurePursuitPhase1(q_true, x_est, P, perimeter_trajectory, ...
    L, Ld_line, umin, umax, Qmin, Qmax, tau_gamma, tau_v, Q_odo, R_gps, H, ...
    logOdds, map_R, map_C, Xmax, Ymax, p_occ, p_free, ...
    path_x, path_y, scan_count, step_count, gps_idx, median_window_size, ...
    h_map, current_phase);

% Detect trees from perimeter scan
fprintf('\nDetecting trees from perimeter scan...\n');
[detected_trees, tree_diameters] = detectTrees(logOdds, Xmax, Ymax, ...
    'MinRadius', 0.1, 'MaxRadius', 1.0, 'OccThreshold', 0.55, 'Visualize', false);


fprintf('*** PHASE 1 Completed: Most northeastern trees detected! ***\n');
fprintf('Detected %d trees. Starting tree block navigation.\n', length(tree_diameters));

% Save log map
logOdds_1 = logOdds;
% Update tree block bounds based on detections
if ~isempty(detected_trees)
    detected_block_bounds.xmin = min(detected_trees(:,1)) - 1;
    detected_block_bounds.xmax = max(detected_trees(:,1)) + 1;
    detected_block_bounds.ymin = min(detected_trees(:,2)) - 1;
    detected_block_bounds.ymax = max(detected_trees(:,2)) + 1;
    fprintf('Detected tree block bounds: X[%.1f, %.1f], Y[%.1f, %.1f]\n', ...
        detected_block_bounds.xmin, detected_block_bounds.xmax, ...
        detected_block_bounds.ymin, detected_block_bounds.ymax);
else
    detected_block_bounds = tree_block_bounds; % Use ground truth as fallback
    fprintf('No trees detected, using ground truth bounds\n');
end

%% PHASE 2 EXECUTION: Column-wise tree block traversal
fprintf('\nExecuting Phase 2: Column-wise Tree Block Traversal\n');
fprintf('Phase 2 Terminal Condition: Detect more than 30 trees\n');
current_phase = 2;

% Plan column traversal pattern
column_trajectory = planColumnTraversalTrajectory(detected_block_bounds, W, D);

% Execute column traversal with pure pursuit segmented
[q_true, x_est, P, logOdds, path_x, path_y, scan_count, step_count, gps_idx, phase2_terminated] = ...
    executeTrajectoryWithPurePursuitSegmentedPhase2(q_true, x_est, P, column_trajectory, ...
    L, Ld_line, Ld_turn, umin, umax, Qmin, Qmax, tau_gamma, tau_v, Q_odo, R_gps, H, ...
    logOdds, map_R, map_C, Xmax, Ymax, p_occ, p_free, ...
    path_x, path_y, scan_count, step_count, gps_idx, median_window_size, ...
    h_map, current_phase);
% Save log map
logOdds_2 = logOdds;
%% Final tree detection and analysis
fprintf('\nFinal tree detection and analysis...\n');
logOdds_total = min(logOdds_1, logOdds_2);
[final_detected_trees, final_tree_diameters] = detectTrees(logOdds_total, Xmax, Ymax, ...
    'MinRadius', 0.1, 'MaxRadius', 1.0, 'OccThreshold', 0.55, 'Visualize', false);


%% Performance Analysis
fprintf('\n=== FINAL PERFORMANCE ANALYSIS ===\n');
if ~isempty(final_detected_trees)
    [error_stats] = calculateErrorHistograms(final_detected_trees, final_tree_diameters, ground_truth_trees);
    generateOutputFile(final_detected_trees, final_tree_diameters, 'results/navigation_trees.txt');
end

% Calculate total path metrics
total_distance = sum(sqrt(diff(path_x).^2 + diff(path_y).^2));
fprintf('Enhanced Navigation Results:\n');
fprintf('  Total distance traveled: %.1f m\n', total_distance);
fprintf('  Number of LiDAR scans: %d\n', scan_count);
fprintf('  Final position: (%.2f, %.2f)\n', q_true(1), q_true(2));
fprintf('  Trees detected: %d\n', length(final_tree_diameters));
fprintf('  Ground truth trees: %d\n', size(ground_truth_trees, 1));

%% Save results
hold off;
close all;
% Detect trees from the occupancy grid with adjusted parameters
[tree_locations, tree_diameters] = detectTrees(logOdds_total, Xmax, Ymax, ...
    'MinRadius', 0.1, 'MaxRadius', 1.0, 'OccThreshold', 0.55, 'Visualize', false);

%% Create detailed results figure
% 1. Built Occupancy Grid
fig1 = figure;
prob_map = logOddsToProbability(logOdds);
set(fig1, 'Position', [100, 100, 600, 500]);
imagesc(x_im, y_im, prob_map);
set(gca,'YDir','normal'); axis equal;
title('Built Occupancy Grid');
xlabel('X (m)'); ylabel('Y (m)');
colormap(gca, 'hot'); colorbar;
saveas(fig1, 'results/occupancy_grid.png');

%{
 2. Ground Truth vs Detected Tree Locations
fig2 = figure;
set(fig2, 'Position', [100, 100, 600, 500]);
hold on;
plot(ground_truth_trees(:,1), ground_truth_trees(:,2), 'ro', 'MarkerSize', 8, ...
     'MarkerFaceColor', 'red', 'DisplayName', 'Ground Truth');
plot(tree_locations(:,1), tree_locations(:,2), 'bx', 'MarkerSize', 10, ...
     'LineWidth', 2, 'DisplayName', 'Detected');
xlabel('X (m)'); ylabel('Y (m)');
title('Ground Truth vs Detected');
legend('Location', 'best');
grid on; axis equal;
hold off;
saveas(fig2, 'results/ground_truth_vs_detected.png');
%}

% 3. Detected Diameter Distribution
if ~isempty(tree_diameters)
    fig3 = figure;
    set(fig3, 'Position', [100, 100, 600, 500]);
    histogram(tree_diameters, 'BinWidth', 0.05, 'FaceColor', 'blue', 'EdgeColor', 'black');
    xlabel('Tree Diameter (m)');
    ylabel('Number of Trees');
    title('Detected Diameter Distribution');
    grid on;
    hold on;
    mean_diameter = mean(tree_diameters);
    xline(mean_diameter, 'r--', 'LineWidth', 2, ...
          'Label', sprintf('Mean: %.2f m', mean_diameter));
    hold off;
    saveas(fig3, 'results/detected_diameter_distribution.png');
end

% 4. Ground Truth Diameter Distribution
if ~isempty(ground_truth_trees)
    fig4 = figure;
    set(fig4, 'Position', [100, 100, 600, 500]);
    histogram(ground_truth_trees(:,3), 'BinWidth', 0.05, 'FaceColor', 'red', 'EdgeColor', 'black');
    xlabel('Tree Diameter (m)');
    ylabel('Number of Trees');
    title('Ground Truth Diameter Distribution');
    grid on;
    hold on;
    mean_gt_diameter = mean(ground_truth_trees(:,3));
    xline(mean_gt_diameter, 'r--', 'LineWidth', 2, ...
          'Label', sprintf('Mean: %.2f m', mean_gt_diameter));
    hold off;
    saveas(fig4, 'results/ground_truth_diameter_distribution.png');
end

% 5. Ground Truth Environment
fig5 = figure;
set(gcf, 'Position', [50, 50, 1400, 600]);
x_im = [0 Xmax]; y_im = [0 Ymax];
imagesc(x_im, y_im, flip(bitmap));
set(gca,'YDir','normal');
axis equal;
title('Ground Truth Environment');
xlabel('X (m)'); ylabel('Y (m)');
colormap(gca, 'gray');
hold off;
saveas(fig5, 'results/ground_truth_environment.png')

fprintf('\nnavigation complete! Results saved in "results" directory\n');

%% ==================================================================
%                    HELPER FUNCTIONS
%% ==================================================================

function [q_true, x_est, P, logOdds, path_x, path_y, scan_count, step_count, gps_idx, phase_terminated] = ...
    executeTrajectoryWithSimplePurePursuitPhase1(q_true_init, x_est_init, P_init, trajectory, ...
    L, Ld, umin, umax, Qmin, Qmax, tau_gamma, tau_v, Q_odo, R_gps, H, ...
    logOdds, map_R, map_C, Xmax, Ymax, p_occ, p_free, ...
    path_x_init, path_y_init, scan_count_init, step_count_init, gps_idx_init, ...
    median_window_size, h_map, phase)
    
    % Execute Phase 1 with simple pure pursuit controller and terminal condition
    q_true = q_true_init;
    x_est = x_est_init;
    P = P_init;
    path_x = path_x_init;
    path_y = path_y_init;
    scan_count = scan_count_init;
    step_count = step_count_init;
    gps_idx = gps_idx_init;
    phase_terminated = false;
    
    phase_names = {'Perimeter Scan', 'Column Traversal', 'GA Return'};
    fprintf('Executing %s with %d waypoints using simple pure pursuit\n', phase_names{phase}, size(trajectory, 1));
    
    global DT bitmap
    
    
    for wp_idx = 1:size(trajectory, 1)
        target_reached = false;
        waypoint_steps = 0;
        max_waypoint_steps = 1000; % 10 seconds at 10ms timestep
        
        while ~target_reached && waypoint_steps < max_waypoint_steps
            step_count = step_count + 1;
            waypoint_steps = waypoint_steps + 1;
            
            % Simple pure pursuit control
            [steer_cmd, cross_track_error] = purePursuitController(q_true, L, Ld, trajectory(wp_idx:end,:));
            
            % Phase 1 specific velocity
            v_cmd = 1.5;
            u_cmd = [steer_cmd; v_cmd];
            
            % Apply bicycle model dynamics
            [q_true, odo] = robot_odo(q_true, u_cmd, umin, umax, Qmin, Qmax, L, tau_gamma, tau_v);
            
            % EKF prediction and correction
            delta_d = odo(1);
            delta_theta = odo(2);
            theta = x_est(3);
            
            x_pred = x_est + [delta_d*cos(theta); 
                              delta_d*sin(theta); 
                              delta_theta];
            x_pred(3) = wrapToPi(x_pred(3));
            
            Fx = eye(3);
            Fx(1,3) = -delta_d*sin(theta);
            Fx(2,3) = delta_d*cos(theta);
            
            Fu = [cos(theta), 0;
                  sin(theta), 0;
                  0,          1];
            
            P_pred = Fx*P*Fx' + Fu*Q_odo*Fu';
            
            % GPS correction every 100 steps (1 second)
            if mod(step_count, 100) == 0
                gps_idx = gps_idx + 1;
                [x_gps, y_gps, th_gps] = GPS_CompassNoisy(q_true(1), q_true(2), q_true(3));
                z = [x_gps; y_gps; th_gps];
                
                innov = z - x_pred;
                innov(3) = wrapToPi(innov(3));
                
                S = H*P_pred*H' + R_gps;
                K = P_pred*H'/S;
                
                x_est = x_pred + K*innov;
                x_est(3) = wrapToPi(x_est(3));
                P = (eye(3) - K*H)*P_pred;
            else
                x_est = x_pred;
                P = P_pred;
            end
            
            % LiDAR scanning and mapping
            Tl = [cos(q_true(3)), -sin(q_true(3)), q_true(1);
                  sin(q_true(3)),  cos(q_true(3)), q_true(2);
                  0,                0,                 1];
            
            scan = laserScannerNoisy(pi, deg2rad(0.125), 20, Tl, bitmap, Xmax, Ymax);
            ranges_filtered = medfilt1(scan(:,2), median_window_size);
            angles = scan(:,1);
            
            scan_count = scan_count + 1;
            
            % Update occupancy grid
            logOdds = updateLaserBeamGrid(angles, ranges_filtered, Tl, logOdds, ...
                                         map_R, map_C, Xmax, Ymax, p_occ, p_free);
            
            % Store path
            path_x(end+1) = q_true(1);
            path_y(end+1) = q_true(2);
            
            % Check Phase 1 terminal condition every 20 steps (0.2 seconds)
            if mod(step_count, 20) == 0
                [current_trees, ~] = detectTrees(logOdds, Xmax, Ymax, ...
                    'MinRadius', 0.1, 'MaxRadius', 1.0, 'OccThreshold', 0.55, 'Visualize', false);
                
            end
            
            % Check if waypoint reached
            distance_to_waypoint = norm([q_true(1), q_true(2)] - trajectory(wp_idx, :));
            if distance_to_waypoint < 2.0 % 2m tolerance
                target_reached = true;
            end
            
            % Update visualization every 50 steps
            if mod(step_count, 50) == 0
                subplot(1,2,2);
                set(h_map, 'CData', logOddsToProbability(logOdds));
                hold on;
                plot(path_x, path_y, 'g-', 'LineWidth', 1);
                plot(q_true(1), q_true(2), 'bo', 'MarkerSize', 4, 'MarkerFaceColor', 'blue');
                
                % Add orientation arrow
                arrow_len = 2;
                arrow_x = q_true(1) + arrow_len * cos(q_true(3));
                arrow_y = q_true(2) + arrow_len * sin(q_true(3));
                plot([q_true(1), arrow_x], [q_true(2), arrow_y], 'b-', 'LineWidth', 2);
                
                title(sprintf('%s | WP %d/%d | Pos(%.1f,%.1f)', ...
                    phase_names{phase}, wp_idx, size(trajectory,1), q_true(1), q_true(2)));
                hold off;
                drawnow;
            end
        end
        
        if mod(wp_idx, max(1, floor(size(trajectory,1)/10))) == 0
            fprintf('  %s progress: %.1f%% (%d/%d waypoints)\n', ...
                phase_names{phase}, (wp_idx/size(trajectory,1))*100, wp_idx, size(trajectory,1));
        end
    end
    
    fprintf('%s completed with %d scans\n', phase_names{phase}, scan_count - scan_count_init);
end


function [q_true, x_est, P, logOdds, path_x, path_y, scan_count, step_count, gps_idx, phase_terminated] = ...
    executeTrajectoryWithPurePursuitSegmentedPhase2(q_true_init, x_est_init, P_init, trajectory, ...
    L, Ld_line, Ld_turn, umin, umax, Qmin, Qmax, tau_gamma, tau_v, Q_odo, R_gps, H, ...
    logOdds, map_R, map_C, Xmax, Ymax, p_occ, p_free, ...
    path_x_init, path_y_init, scan_count_init, step_count_init, gps_idx_init, ...
    median_window_size, h_map, phase)
    
    % Execute trajectory for Phase 2 with terminal condition: detect more than 30 trees
    q_true = q_true_init;
    x_est = x_est_init;
    P = P_init;
    path_x = path_x_init;
    path_y = path_y_init;
    scan_count = scan_count_init;
    step_count = step_count_init;
    gps_idx = gps_idx_init;
    phase_terminated = false;
    Ld = 5.0;
    
    phase_names = {'Perimeter Scan', 'Column Traversal', 'GA Return'};
    fprintf('Executing %s with %d waypoints\n', phase_names{phase}, size(trajectory, 1));
    
    global DT bitmap
    
    
    
    % Terminal condition tracking for Phase 2
    tree_count_threshold = 30; % Terminate when more than 30 trees detected
    
    for wp_idx = 1:size(trajectory, 1)
        target_reached = false;
        waypoint_steps = 0;
        max_waypoint_steps = 1000; % 10 seconds at 10ms timestep
        
        while ~target_reached && waypoint_steps < max_waypoint_steps
            step_count = step_count + 1;
            waypoint_steps = waypoint_steps + 1;
            
            % Pure pursuit segmented control
            [steer_cmd, cross_track_error] = purePursuitController(q_true, L, Ld, trajectory(wp_idx:end,:));
            
            % Phase 2 specific velocity (slower for detailed scanning)
            v_cmd = 1.0;
            u_cmd = [steer_cmd; v_cmd];
            
            % Apply bicycle model dynamics
            [q_true, odo] = robot_odo(q_true, u_cmd, umin, umax, Qmin, Qmax, L, tau_gamma, tau_v);
            
            % EKF prediction and correction
            delta_d = odo(1);
            delta_theta = odo(2);
            theta = x_est(3);
            
            x_pred = x_est + [delta_d*cos(theta); 
                              delta_d*sin(theta); 
                              delta_theta];
            x_pred(3) = wrapToPi(x_pred(3));
            
            Fx = eye(3);
            Fx(1,3) = -delta_d*sin(theta);
            Fx(2,3) = delta_d*cos(theta);
            
            Fu = [cos(theta), 0;
                  sin(theta), 0;
                  0,          1];
            
            P_pred = Fx*P*Fx' + Fu*Q_odo*Fu';
            
            % GPS correction every 100 steps (1 second)
            if mod(step_count, 100) == 0
                gps_idx = gps_idx + 1;
                [x_gps, y_gps, th_gps] = GPS_CompassNoisy(q_true(1), q_true(2), q_true(3));
                z = [x_gps; y_gps; th_gps];
                
                innov = z - x_pred;
                innov(3) = wrapToPi(innov(3));
                
                S = H*P_pred*H' + R_gps;
                K = P_pred*H'/S;
                
                x_est = x_pred + K*innov;
                x_est(3) = wrapToPi(x_est(3));
                P = (eye(3) - K*H)*P_pred;
            else
                x_est = x_pred;
                P = P_pred;
            end
            
            % LiDAR scanning and mapping
            Tl = [cos(q_true(3)), -sin(q_true(3)), q_true(1);
                  sin(q_true(3)),  cos(q_true(3)), q_true(2);
                  0,                0,                 1];
            
            scan = laserScannerNoisy(pi, deg2rad(0.125), 20, Tl, bitmap, Xmax, Ymax);
            ranges_filtered = medfilt1(scan(:,2), median_window_size);
            angles = scan(:,1);
            
            scan_count = scan_count + 1;
            
            % Update occupancy grid
            logOdds = updateLaserBeamGrid(angles, ranges_filtered, Tl, logOdds, ...
                                         map_R, map_C, Xmax, Ymax, p_occ, p_free);
            
            % Store path
            path_x(end+1) = q_true(1);
            path_y(end+1) = q_true(2);
            
            
            % Check if waypoint reached
            distance_to_waypoint = norm([q_true(1), q_true(2)] - trajectory(wp_idx, :));
            if distance_to_waypoint < 2.0 % 2m tolerance
                target_reached = true;
            end

            % Terminate the loop if approach the origin
            if norm([q_true(1), q_true(2)] - [0, 0]) < 3 && size(wp_idx, 1) <= 100
                break
            end
            
            % Update visualization every 50 steps
            if mod(step_count, 50) == 0
                subplot(1,2,2);
                set(h_map, 'CData', logOddsToProbability(logOdds));
                hold on;
                plot(path_x, path_y, 'g-', 'LineWidth', 1);
                plot(q_true(1), q_true(2), 'bo', 'MarkerSize', 4, 'MarkerFaceColor', 'blue');
                
                % Add orientation arrow
                arrow_len = 2;
                arrow_x = q_true(1) + arrow_len * cos(q_true(3));
                arrow_y = q_true(2) + arrow_len * sin(q_true(3));
                plot([q_true(1), arrow_x], [q_true(2), arrow_y], 'b-', 'LineWidth', 2);
                
                title(sprintf('%s | WP %d/%d | Pos(%.1f,%.1f)', ...
                    phase_names{phase}, wp_idx, size(trajectory,1), q_true(1), q_true(2)));
                hold off;
                drawnow;
            end
        end
        
        if mod(wp_idx, max(1, floor(size(trajectory,1)/10))) == 0
            fprintf('  %s progress: %.1f%% (%d/%d waypoints)\n', ...
                phase_names{phase}, (wp_idx/size(trajectory,1))*100, wp_idx, size(trajectory,1));
        end

    end
    
    fprintf('%s completed with %d scans\n', phase_names{phase}, scan_count - scan_count_init);
end


function trajectory = planPerimeterScanTrajectory(Xmax, Ymax)
    % Plan comprehensive perimeter scan with proper turning waypoints
    % Stop before reaching (Xmax, Ymax) to prepare for tree block entry
    fprintf('Planning perimeter scan trajectory with proper turns...\n');
    
    trajectory = [];
    spacing = 1.0;  % Tighter spacing for better scanning and navigation
    
    % Calculate turning radius for smooth transitions
    L = 3; % wheelbase
    gamma_limit = deg2rad(55); % max steering angle
    Rmin = L / tan(gamma_limit);
    turn_offset = Rmin + 1; % Extra margin for safe turning
    
    % Define perimeter bounds (stop before max values)
    x_limit = Xmax - 10; % Stop 5m before eastern edge
    y_limit = Ymax; % Stop before northern edge
    
    fprintf('  Perimeter bounds: X[0, %.1f], Y[0, %.1f]\n', x_limit, y_limit);
    fprintf('  Minimum turning radius: %.1f m\n', Rmin);
    
    % Phase 1: Western edge - (0,0) to (0, y_limit)
    fprintf('  Planning western edge trajectory...\n');
    y_points = 0:spacing:y_limit;
    for y = y_points
        trajectory(end+1, :) = [0, y];
    end
    fprintf('    Added %d waypoints along western edge\n', length(y_points));
    
    % Phase 2: Northwestern corner turn - smooth 90° turn
    fprintf('  Planning northwestern corner turn...\n');
    corner_x = 0;
    corner_y = y_limit;
    
    % Add intermediate waypoints for smooth 90-degree turn
    turn_waypoints = planCornerTurn(corner_x, corner_y, 'NE', Rmin);
    for i = 1:size(turn_waypoints, 1)
        trajectory(end+1, :) = turn_waypoints(i, :);
    end
    fprintf('    Added %d waypoints for northwestern turn\n', size(turn_waypoints, 1));
    
    % Phase 3: Northern edge - (turn_end_x, y_limit) to (x_limit, y_limit)
    fprintf('  Planning northern edge trajectory...\n');
    turn_end_x = trajectory(end, 1); % X coordinate where turn ended
    
    % Ensure we have waypoints from turn end to eastern limit
    x_start = max(turn_end_x + spacing, spacing); % Start after turn
    x_points = x_start:spacing:x_limit;
    
    for x = x_points
        trajectory(end+1, :) = [x, y_limit];
    end
    fprintf('    Added %d waypoints along northern edge\n', length(x_points));

    
    % Validate trajectory
    fprintf('\nTrajectory validation:\n');
    fprintf('  Total waypoints: %d\n', size(trajectory, 1));
    fprintf('  Start point: (%.1f, %.1f)\n', trajectory(1, 1), trajectory(1, 2));
    fprintf('  End point: (%.1f, %.1f)\n', trajectory(end, 1), trajectory(end, 2));
    
    % Check for proper spacing and validate turns
    distances = [];
    for i = 2:size(trajectory, 1)
        dist = norm(trajectory(i, :) - trajectory(i-1, :));
        distances(end+1) = dist;
    end
    fprintf('  Average waypoint spacing: %.2f m\n', mean(distances));
    fprintf('  Max waypoint spacing: %.2f m\n', max(distances));
    
    fprintf('Perimeter scan trajectory planning completed!\n');
end

function trajectory = planColumnTraversalTrajectory(tree_bounds, W, D)
    % Edge-only traversal with smooth corner turning, then return to (0,0)
    fprintf('Planning smooth edge traversal starting from northeastern corner...\n');

    % Vehicle parameters
    L = 3;
    gamma_limit = deg2rad(55);
    Rmin = L / tan(gamma_limit);
    x_ro = 32;
    y_ro = 39;

    % Tree block bounds
    xmin = tree_bounds.xmin;
    xmax = tree_bounds.xmax;
    ymin = tree_bounds.ymin;
    ymax = tree_bounds.ymax;

    trajectory = [];
    
    % Step 1: Approach point near northeast
    trajectory = planCornerTurn(x_ro, y_ro, 'ES', Rmin)
    approach_x = xmax;
    approach_y = (ymax - ymin)/2 + ymin;
    x_interp = linspace(x_ro, approach_x, 20);
    y_interp = linspace(y_ro, approach_y, 20);
    for i = 1:length(x_interp)
        trajectory(end+1, :) = [x_interp(i), y_interp(i)];
    end

    % Step 2: Traverse right edge down (xmax, ymax to xmax, ymin)
    y_right = linspace(approach_y - Rmin, ymin + Rmin, 5);
    for y = y_right
        trajectory(end+1, :) = [xmax, y];
    end

    % Step 3: Smooth turn from South to West along bottom edge
    trajectory = [trajectory; planCornerTurn(xmax, ymin, 'SW', Rmin)];

    % Step 4: Traverse bottom edge left (xmax to xmin at ymin)
    x_bot = linspace(xmax - Rmin, xmin + Rmin, 20);
    for x = x_bot
        trajectory(end+1, :) = [x, ymin];
    end

    %Step 5: Traverse left edge top
    trajectory = [trajectory; planCornerTurn(xmin, ymin + Rmin, 'SE', Rmin)];
    y_left = linspace(ymin, ymax + Rmin, 20);
    for y = y_left
        trajectory(end+1, :) = [xmin, y + Rmin];
    end

    % Step 7: Return to (0,0)
    last_pt = trajectory(end, :);
    return_x = linspace(last_pt(1), 0, 30);
    return_y = linspace(last_pt(2), 0, 30);
    for i = 1:length(return_x)
        trajectory(end+1, :) = [return_x(i), return_y(i)];
    end

    fprintf('Smooth edge traversal complete. Total waypoints: %d\n', size(trajectory, 1));
end

function turn_waypoints = planCornerTurn(corner_x, corner_y, direction, Rmin)
    % Plan smooth corner turn waypoints
    % direction: 'NE' (North to East), 'EN' (East to North), etc.
    
    turn_waypoints = [];
    turn_spacing = 0.5; % Finer spacing for turns
    
    switch direction
        case 'NE' % Northwestern corner: turning from North-bound to East-bound
            % Create arc from facing North to facing East
            center_x = corner_x + Rmin;
            center_y = corner_y;
            
            % Arc from 180° (facing North) to 90° (facing East)
            start_angle = pi; % 180° (West direction from center)
            end_angle = pi/2; % 90° (North direction from center)
            
            % Create arc waypoints
            angles = linspace(start_angle, end_angle, 8); % 8 points for smooth turn
            for i = 1:length(angles)
                x = center_x + Rmin * cos(angles(i));
                y = center_y + Rmin * sin(angles(i));
                turn_waypoints(end+1, :) = [x, y];
            end
            
        case 'EN' % Northeastern corner: turning from East-bound to North-bound  
            center_x = corner_x;
            center_y = corner_y + Rmin;
            
            start_angle = 3*pi/2; % 270° (South direction from center)
            end_angle = 0; % 0° (East direction from center)
            
            angles = linspace(start_angle, end_angle, 8);
            for i = 1:length(angles)
                x = center_x + Rmin * cos(angles(i));
                y = center_y + Rmin * sin(angles(i));
                turn_waypoints(end+1, :) = [x, y];
            end
            
        case 'SE' % Southeastern corner: turning from South-bound to East-bound
            center_x = corner_x + Rmin;
            center_y = corner_y;
            
            start_angle = pi; % 180° (West direction from center)
            end_angle = 3*pi/2; % 270° (South direction from center)
            
            angles = linspace(start_angle, end_angle, 8);
            for i = 1:length(angles)
                x = center_x + Rmin * cos(angles(i));
                y = center_y + Rmin * sin(angles(i));
                turn_waypoints(end+1, :) = [x, y];
            end
            
        case 'ES' % Northeastern corner: turning from East-bound to South-bound
            center_x = corner_x;
            center_y = corner_y - Rmin;
            
            start_angle = pi/2; % 90° (North direction from center)
            end_angle = 0; % 0° (East direction from center)
            
            angles = linspace(start_angle, end_angle, 8);
            for i = 1:length(angles)
                x = center_x + Rmin * cos(angles(i));
                y = center_y + Rmin * sin(angles(i));
                turn_waypoints(end+1, :) = [x, y];
            end
        case 'SW' % Southeastern corner: turning from South-bound to West-bound
            center_x = corner_x - Rmin;
            center_y = corner_y + Rmin;
            
            start_angle = 0; % 90° (South direction from center)
            end_angle = -pi/2; % 180° (West direction from center)
            
            angles = linspace(start_angle, end_angle, 8);
            for i = 1:length(angles)
                x = center_x + Rmin * cos(angles(i));
                y = center_y + Rmin * sin(angles(i));
                turn_waypoints(end+1, :) = [x, y];
            end
    end
    
    fprintf('      Corner turn (%s): %d waypoints, radius %.1f m\n', ...
        direction, size(turn_waypoints, 1), Rmin);
end

function dist = distancePointToLine(point, line_start, line_end)
    % Calculate distance from point to line segment
    v = line_end - line_start;
    w = point - line_start;
    
    if dot(v,v) == 0
        dist = norm(w);
        return;
    end
    
    t = max(0, min(1, dot(w,v) / dot(v,v)));
    projection = line_start + t * v;
    dist = norm(point - projection);
end

% [Include all remaining original helper functions exactly as they were]
function [Q_odo, R_gps] = estimateSensorCovariances(q_init, L, tau_gamma, tau_v, ...
    umin, umax, Qmin, Qmax, bitmap, Xmax, Ymax)
    global dt DT
    
    cal_time = 30;
    cal_steps = round(cal_time / DT);
    
    q_true_cal = zeros(cal_steps, 5);
    odo_true_cal = zeros(cal_steps, 2);
    odo_noisy_cal = zeros(cal_steps, 2);
    gps_true_cal = zeros(floor(cal_steps/100)+1, 3);
    gps_noisy_cal = zeros(floor(cal_steps/100)+1, 3);
    
    q = q_init;
    gps_idx = 0;
    
    fprintf('Running sensor calibration sequence...\n');
    
    for k = 1:cal_steps
        t = k * DT;
        omega = 2*pi/15;
        delta = 0.3 * sin(omega * t);
        v_ref = 1.5;
        
        u_cmd = [delta; v_ref];
        
        [q_new_true, odo_true] = robot_odo_unnoisy(q, u_cmd, umin, umax, Qmin, Qmax, L, tau_gamma, tau_v);
        [q_new_noisy, odo_noisy] = robot_odo(q, u_cmd, umin, umax, Qmin, Qmax, L, tau_gamma, tau_v);
        
        q_true_cal(k,:) = q_new_true';
        odo_true_cal(k,:) = odo_true';
        odo_noisy_cal(k,:) = odo_noisy';
        
        q = q_new_true;
        
        if mod(k, 100) == 0
            gps_idx = gps_idx + 1;
            [x_true, y_true, th_true] = GPS_Compass_unnoisy(q(1), q(2), q(3));
            gps_true_cal(gps_idx,:) = [x_true, y_true, th_true];
            [x_noisy, y_noisy, th_noisy] = GPS_CompassNoisy(q(1), q(2), q(3));
            gps_noisy_cal(gps_idx,:) = [x_noisy, y_noisy, th_noisy];
        end
    end
    
    odo_errors = odo_noisy_cal - odo_true_cal;
    Q_odo = cov(odo_errors);
    
    gps_errors = gps_noisy_cal(1:gps_idx,:) - gps_true_cal(1:gps_idx,:);
    gps_errors(:,3) = wrapToPi(gps_errors(:,3));
    R_gps = cov(gps_errors);
    
    fprintf('Calibration completed with %d odometry and %d GPS samples\n', cal_steps, gps_idx);
end

function [q_true_next, odo] = robot_odo_unnoisy(q_true, u, umin, umax, Qmin, Qmax, L, tau_gamma, tau_v)
    global dt DT
    
    x = q_true(1); y = q_true(2); theta = q_true(3); 
    gamma = q_true(4); v = q_true(5);
    
    gamma_des = u(1); v_des = u(2);
    gamma_des = max(umin(1), min(gamma_des, umax(1)));
    v_des = max(umin(2), min(v_des, umax(2)));
    
    steps = max(1, round(DT / dt));
    q_current = q_true;
    
    for i = 1:steps
        gamma_dot = (gamma_des - q_current(4)) / tau_gamma;
        v_dot = (v_des - q_current(5)) / tau_v;
        
        q_current(4) = q_current(4) + gamma_dot * dt;
        q_current(5) = q_current(5) + v_dot * dt;
        
        q_current(4) = max(Qmin(4), min(q_current(4), Qmax(4)));
        q_current(5) = max(Qmin(5), min(q_current(5), Qmax(5)));
        
        if abs(q_current(5)) > 1e-6
            x_dot = q_current(5) * cos(q_current(3));
            y_dot = q_current(5) * sin(q_current(3));
            theta_dot = q_current(5) * tan(q_current(4)) / L;
            
            q_current(1) = q_current(1) + x_dot * dt;
            q_current(2) = q_current(2) + y_dot * dt;
            q_current(3) = q_current(3) + theta_dot * dt;
        end
    end
    
    q_current(3) = wrapToPi(q_current(3));
    q_true_next = q_current;
    
    delta_pos = q_true_next(1:2) - q_true(1:2);
    distance_traveled = norm(delta_pos);
    angle_change = wrapToPi(q_true_next(3) - q_true(3));
    
    odo = [distance_traveled; angle_change];
end

function [x_n, y_n, theta_n] = GPS_Compass_unnoisy(x, y, theta)
    x_n = x;
    y_n = y;
    theta_n = theta;
end

function [q_true_next, odo] = robot_odo(q_true, u, umin, umax,Qmin, Qmax, L, tau_gamma, tau_v)
    global dt DT
    
    x = q_true(1); y = q_true(2); theta = q_true(3); 
    gamma = q_true(4); v = q_true(5);
    
    gamma_des = u(1); v_des = u(2);
    gamma_des = max(umin(1), min(gamma_des, umax(1)));
    v_des = max(umin(2), min(v_des, umax(2)));
    
    steps = max(1, round(DT / dt));
    q_current = q_true;
    
    for i = 1:steps
        gamma_dot = (gamma_des - q_current(4)) / tau_gamma;
        v_dot = (v_des - q_current(5)) / tau_v;
        
        q_current(4) = q_current(4) + gamma_dot * dt;
        q_current(5) = q_current(5) + v_dot * dt;
        
        q_current(4) = max(Qmin(4), min(q_current(4), Qmax(4)));
        q_current(5) = max(Qmin(5), min(q_current(5), Qmax(5)));
        
        if abs(q_current(5)) > 1e-6
            x_dot = q_current(5) * cos(q_current(3));
            y_dot = q_current(5) * sin(q_current(3));
            theta_dot = q_current(5) * tan(q_current(4)) / L;
            
            q_current(1) = q_current(1) + x_dot * dt;
            q_current(2) = q_current(2) + y_dot * dt;
            q_current(3) = q_current(3) + theta_dot * dt;
        end
    end
    
    q_current(3) = wrapToPi(q_current(3));
    q_true_next = q_current;
    
    delta_pos = q_true_next(1:2) - q_true(1:2);
    distance_traveled = norm(delta_pos);
    angle_change = wrapToPi(q_true_next(3) - q_true(3));
    
    distance_noise_std = max(0.01, 0.02 * distance_traveled);
    angle_noise_std = max(0.005, 0.01 * abs(angle_change));
    
    if distance_traveled > 0.001
        distance_bias = 0.98 + 0.04 * rand();
        distance_traveled = distance_traveled * distance_bias;
    end
    
    odo = [distance_traveled + distance_noise_std * randn(); 
           angle_change + angle_noise_std * randn()];
end

function [x_n, y_n, theta_n] = GPS_CompassNoisy(x, y, theta)
    gps_horizontal_std = 3.0;
    gps_bias_x = 1.0 * (2*rand() - 1);
    gps_bias_y = 1.0 * (2*rand() - 1);
    
    compass_std = deg2rad(8);
    compass_bias = deg2rad(5) * (2*rand() - 1);
    
    if rand() < 0.05
        gps_horizontal_std = gps_horizontal_std * 3;
    end
    
    if rand() < 0.02
        compass_std = compass_std * 2;
    end
    
    x_n = x + gps_bias_x + gps_horizontal_std * randn();
    y_n = y + gps_bias_y + gps_horizontal_std * randn();
    theta_n = theta + compass_bias + compass_std * randn();
    
    theta_n = wrapToPi(theta_n);
end

function p = laserScannerNoisy(angleSpan, angleStep, rangeMax, Tl, map, Xmax, Ymax)
    angles = (-angleSpan/2:angleStep:angleSpan/2)';
    num_beams = length(angles);
    ranges = zeros(num_beams, 1);
    
    [R, C] = size(map);
    
    scanner_x = Tl(1, 3);
    scanner_y = Tl(2, 3);
    scanner_theta = atan2(Tl(2, 1), Tl(1, 1));
    
    for i = 1:num_beams
        beam_angle = scanner_theta + angles(i);
        
        range = 0;
        step = 0.02;
        
        while range < rangeMax
            x_ray = scanner_x + range * cos(beam_angle);
            y_ray = scanner_y + range * sin(beam_angle);
            
            if x_ray < 0 || x_ray >= Xmax || y_ray < 0 || y_ray >= Ymax
                ranges(i) = range;
                break;
            end
            
            [I, J] = XYtoIJ(x_ray, y_ray, Xmax, Ymax, R, C);
            
            if map(I, J) == 1
                ranges(i) = range;
                break;
            end
            
            range = range + step;
        end
        
        if range >= rangeMax
            ranges(i) = rangeMax;
        end
    end
    
    for i = 1:num_beams
        if ranges(i) < rangeMax
            range_noise_std = 0.02 + 0.001 * ranges(i);
            ranges(i) = ranges(i) + range_noise_std * randn();
            
            if rand() < 0.01
                if rand() < 0.5
                    ranges(i) = ranges(i) * (0.5 + 0.5*rand());
                else
                    ranges(i) = rangeMax;
                end
            end
            
            ranges(i) = max(0.1, min(ranges(i), rangeMax));
        end
    end
    
    p = [angles, ranges];
end

function angle_wrapped = wrapToPi(angle)
    angle_wrapped = mod(angle + pi, 2*pi) - pi;
end

function logOdds = updateLaserBeamGrid(angles, ranges, Tl, logOdds, R, C, Xmax, Ymax, p_occ, p_free)
    if nargin < 10 || isempty(p_occ), p_occ = 0.7; end
    if nargin < 11 || isempty(p_free), p_free = 0.3; end
    
    l_occ = log(p_occ / (1-p_occ));
    l_free = log(p_free / (1-p_free));
    
    cellW = Xmax / C;
    cellH = Ymax / R;
    
    originW = Tl * [0; 0; 1];
    ox = originW(1); oy = originW(2);
    oj = min(max(floor(ox / cellW) + 1, 1), C);
    oi = min(max(floor(oy / cellH) + 1, 1), R);
    
    N = numel(angles);
    finiteMask = isfinite(ranges);
    if any(finiteMask)
        finite_ranges = ranges(finiteMask);
        rangeMax = max([hypot(Xmax, Ymax), finite_ranges(:)']);
    else
        rangeMax = hypot(Xmax, Ymax);
    end
    rClip = ranges(:);
    rClip(~finiteMask) = rangeMax;
    
    angles_col = angles(:);
    rClip_col = rClip(:);
    
    xyL = [rClip_col .* cos(angles_col), ...
           rClip_col .* sin(angles_col), ...
           ones(N, 1)]';
    xyW = Tl * xyL;
    
    tj = min(max(floor(xyW(1,:) ./ cellW) + 1, 1), C);
    ti = min(max(floor(xyW(2,:) ./ cellH) + 1, 1), R);
    
    for k = 1:N
        lin = raycastCells(oi, oj, ti(k), tj(k), R);
        
        if finiteMask(k) && ranges(k) < rangeMax * 0.9
            logOdds(lin(end)) = logOdds(lin(end)) + l_occ;
            if numel(lin) > 1
                logOdds(lin(1:end-1)) = logOdds(lin(1:end-1)) + l_free;
            end
        else
            logOdds(lin) = logOdds(lin) + l_free;
        end
    end
end

function lin = raycastCells(i0, j0, i1, j1, R)
    di = i1 - i0; dj = j1 - j0;
    steps = max(abs(di), abs(dj));
    
    if steps == 0
        lin = i0 + (j0-1)*R; 
        return;
    end
    
    t = 0:steps;
    I = round(i0 + di .* t / steps);
    J = round(j0 + dj .* t / steps);
    lin = I + (J-1)*R;
end

function [I, J] = XYtoIJ(x, y, Xmax, Ymax, R, C)
    cellW = Xmax / C;
    cellH = Ymax / R;
    J = min(max(floor(x/cellW) + 1, 1), C);
    I = min(max(R - floor(y/cellH), 1), R);
end

function draw_disc(I, J, radius, R, C)
    global bitmap;
    r_int = ceil(radius);
    for di = -r_int:r_int
        for dj = -r_int:r_int
            i_new = I + di;
            j_new = J + dj;
            if i_new >= 1 && i_new <= R && j_new >= 1 && j_new <= C
                if sqrt(di^2 + dj^2) <= radius
                    bitmap(i_new, j_new) = 1;
                end
            end
        end
    end
end

function prob = logOddsToProbability(logOdds)
    prob = 1 ./ (1 + exp(-logOdds));
end

function [tree_locations, tree_diameters] = detectTrees(logOdds, Xmax, Ymax, varargin)
    %DETECTTREES Detect and localize trees from occupancy grid data
    
    % Parse input arguments
    p = inputParser;
    addParameter(p, 'MinRadius', 0.15, @isnumeric);
    addParameter(p, 'MaxRadius', 0.8, @isnumeric);
    addParameter(p, 'OccThreshold', 0.55, @isnumeric);
    addParameter(p, 'Visualize', true, @islogical);
    addParameter(p, 'MinTreeArea', 2, @isnumeric);
    addParameter(p, 'MaxTreeArea', 500, @isnumeric);
    parse(p, varargin{:});
    
    min_radius = p.Results.MinRadius;
    max_radius = p.Results.MaxRadius;
    occ_threshold = p.Results.OccThreshold;
    min_area = p.Results.MinTreeArea;
    max_area = p.Results.MaxTreeArea;
    
    [R, C] = size(logOdds);
    cell_size_x = Xmax / C;
    cell_size_y = Ymax / R;
    cell_size = mean([cell_size_x, cell_size_y]);
    
    %fprintf('Grid resolution: %.4f m/cell\n', cell_size);
    
    % Convert log-odds to probability
    prob_map = logOddsToProbability(logOdds);
    
    % Create binary occupancy map with lower threshold
    binary_map = prob_map > occ_threshold;
    
    % Remove edge artifacts - exclude boundary regions
    boundary_margin = 5; % pixels
    binary_map(1:boundary_margin, :) = 0;
    binary_map(end-boundary_margin+1:end, :) = 0;
    binary_map(:, 1:boundary_margin) = 0;
    binary_map(:, end-boundary_margin+1:end) = 0;
    
    % Apply more aggressive morphological operations for high-res grids
    if cell_size < 0.02  % High resolution grid
        se_small = strel('disk', 2);  % Larger structuring element
        se_large = strel('disk', 3);
        
        % Remove very small noise
        binary_map = bwareaopen(binary_map, 4);
        
        % More aggressive closing to connect tree parts
        binary_map = imclose(binary_map, se_large);
        binary_map = imopen(binary_map, se_small);
        
        %fprintf('Applied high-resolution morphological operations\n');
    else
        se_small = strel('disk', 1);
        binary_map = bwareaopen(binary_map, 2);
        binary_map = imclose(binary_map, se_small);
        binary_map = imopen(binary_map, se_small);
    end
    
    % Find connected components
    cc = bwconncomp(binary_map);
    stats = regionprops(cc, 'Area', 'Centroid', 'BoundingBox', ...
                       'EquivDiameter', 'Eccentricity', 'Solidity');
    
    %fprintf('Found %d connected components\n', length(stats));
    
    % Filter components with more relaxed criteria
    valid_trees = [];
    for i = 1:length(stats)
        area = stats(i).Area;
        eccentricity = stats(i).Eccentricity;
        solidity = stats(i).Solidity;
        centroid = stats(i).Centroid;
        
        % Convert centroid to world coordinates
        x_world = (centroid(1) - 1) * cell_size_x;
        y_world = (R - centroid(2)) * cell_size_y;
        
        % Boundary check
        margin_world = 2.0; % meters
        if x_world < margin_world || x_world > (Xmax - margin_world) || ...
           y_world < margin_world || y_world > (Ymax - margin_world)
            continue;
        end
        
        % More relaxed filter criteria
        if area >= min_area && area <= max_area && ...
           eccentricity < 0.95 && solidity > 0.5  % Very relaxed
            valid_trees(end+1) = i;
        end
    end
    
    %fprintf('After filtering: %d valid trees\n', length(valid_trees));
    
    % Extract tree information
    num_trees = length(valid_trees);
    tree_locations = zeros(num_trees, 2);
    tree_diameters = zeros(num_trees, 1);
    
    for i = 1:num_trees
        tree_idx = valid_trees(i);
        
        % Get centroid in grid coordinates
        centroid_grid = stats(tree_idx).Centroid; % [col, row]
        
        % Convert to world coordinates
        x_world = (centroid_grid(1) - 1) * cell_size_x;
        y_world = (R - centroid_grid(2)) * cell_size_y;
        
        tree_locations(i, :) = [x_world, y_world];
        
        % Estimate diameter using multiple methods
        area_pixels = stats(tree_idx).Area;
        equiv_diameter_pixels = stats(tree_idx).EquivDiameter;
        
        % Method 1: From equivalent diameter
        diameter_method1 = equiv_diameter_pixels * cell_size;
        
        % Method 2: From area (assuming circular)
        radius_from_area = sqrt(area_pixels / pi);
        diameter_method2 = 2 * radius_from_area * cell_size;
        
        % Method 3: From bounding box
        bbox = stats(tree_idx).BoundingBox;
        min_bbox_dim = min(bbox(3), bbox(4));
        diameter_method3 = min_bbox_dim * cell_size;
        
        % Use median of methods
        diameter_estimates = [diameter_method1, diameter_method2, diameter_method3];
        raw_diameter = median(diameter_estimates);
        
        % Much gentler clamping - allow more variation
        min_allowed = 0.1;  % Very permissive minimum
        max_allowed = 1.2;  % Reasonable maximum
        tree_diameters(i) = max(min_allowed, min(raw_diameter, max_allowed));
        
        %{fprintf('Tree %d: Area=%.1f, Methods=[%.3f, %.3f, %.3f] -> Raw=%.3f -> Final=%.3f\n', i, area_pixels, diameter_method1, diameter_method2, diameter_method3, raw_diameter, tree_diameters(i));
         %}
    end
    %{
    % Remove duplicates - pass the binary map directly to avoid global variable issues
    fprintf('Before duplicate removal: %d trees\n', length(tree_diameters));
    [tree_locations, tree_diameters] = removeDuplicateTreesAggressive(tree_locations, tree_diameters, cell_size, Xmax, Ymax, binary_map);
    fprintf('After duplicate removal: %d trees\n', length(tree_diameters));
    
    % Print summary
    fprintf('\nFinal Tree Detection Results:\n');
    fprintf('=============================\n');
    fprintf('Number of trees detected: %d\n', length(tree_diameters));
    if ~isempty(tree_diameters)
        fprintf('Average diameter: %.3f m\n', mean(tree_diameters));
        fprintf('Diameter range: %.3f - %.3f m\n', min(tree_diameters), max(tree_diameters));
        fprintf('Diameter std: %.3f m\n', std(tree_diameters));
    end
    %}
end

function [filtered_locations, filtered_diameters] = removeDuplicateTreesAggressive(locations, diameters, cell_size, Xmax, Ymax, binary_map)
    %REMOVEDUPLICATETREESAGGRESSIVE Very aggressive duplicate removal with border-based diameter calculation
    
    n = size(locations, 1);
    if n <= 1
        filtered_locations = locations;
        filtered_diameters = diameters;
        return;
    end
    
    %fprintf('Aggressive duplicate removal with border detection from %d trees...\n', n);
    
    % Clean the binary map
    se_small = strel('disk', 1);
    binary_map = bwareaopen(binary_map, 2);
    binary_map = imclose(binary_map, se_small);
    
    % Calculate expected tree spacing from ground truth (approximately 2m)
    expected_tree_spacing = 1.8;  % meters
    
    % Use much larger merging distance for high-resolution grids
    if cell_size < 0.02  % High resolution
        merge_distance = max(1.2, expected_tree_spacing * 0.8);
        %fprintf('High-resolution grid detected, using merge distance: %.2f m\n', merge_distance);
    else
        merge_distance = max(0.8, expected_tree_spacing * 0.6);
        %fprintf('Standard resolution grid, using merge distance: %.2f m\n', merge_distance);
    end
    
    % Use hierarchical clustering to find groups
    distance_matrix = pdist2(locations, locations);
    adjacency = distance_matrix < merge_distance & distance_matrix > 0;
    groups = findConnectedComponents(adjacency);
    
    %fprintf('Found %d groups for merging (expected ~35 trees)\n', length(groups));
    
    % Process each group with border-based diameter calculation
    filtered_locations = [];
    filtered_diameters = [];
    
    [R, C] = size(binary_map);
    
    for g = 1:length(groups)
        group_indices = groups{g};
        
        if length(group_indices) == 1
            % Single tree - keep as is but try to improve diameter
            tree_location = locations(group_indices, :);
            tree_diameter = calculateDiameterFromBorders(tree_location, binary_map, cell_size, R, C, Xmax, Ymax);
            
            filtered_locations(end+1, :) = tree_location;
            filtered_diameters(end+1) = tree_diameter;
        else
            % Multiple trees - find borders and calculate proper diameter
            group_locs = locations(group_indices, :);
            
            % Use centroid for position
            merged_location = mean(group_locs, 1);
            
            % Calculate diameter from actual tree borders
            merged_diameter = calculateDiameterFromBorders(merged_location, binary_map, cell_size, R, C, Xmax, Ymax);
            
            filtered_locations(end+1, :) = merged_location;
            filtered_diameters(end+1) = merged_diameter;
            
            %fprintf('Merged %d trees at (%.2f, %.2f) -> border-based diameter %.3f\n', length(group_indices), merged_location(1), merged_location(2), merged_diameter);
        end
    end
    
    % Final spatial check - ensure minimum separation
    if size(filtered_locations, 1) > 1
        final_distance = expected_tree_spacing * 0.7;
        keep = true(size(filtered_locations, 1), 1);
        
        % Sort by "quality" - prefer trees with reasonable diameters
        reasonable_diameter = 0.4;
        quality_scores = 1 ./ (abs(filtered_diameters - reasonable_diameter) + 0.1);
        [~, sort_idx] = sort(quality_scores, 'descend');
        
        for i = 1:length(sort_idx)
            if ~keep(sort_idx(i)), continue; end
            
            for j = i+1:length(sort_idx)
                if ~keep(sort_idx(j)), continue; end
                
                distance = norm(filtered_locations(sort_idx(i),:) - filtered_locations(sort_idx(j),:));
                if distance < final_distance
                    keep(sort_idx(j)) = false;
                    %fprintf('Final removal: eliminated tree at (%.2f, %.2f) too close to (%.2f, %.2f)\n', filtered_locations(sort_idx(j),1), filtered_locations(sort_idx(j),2), filtered_locations(sort_idx(i),1), filtered_locations(sort_idx(i),2));
                end
            end
        end
        
        filtered_locations = filtered_locations(keep, :);
        filtered_diameters = filtered_diameters(keep);
    end
    
    %fprintf('Final result: %d trees (expected ~35)\n', length(filtered_diameters));
    
    % Display diameter statistics
    if ~isempty(filtered_diameters)
        fprintf('Diameter statistics: mean=%.3f, std=%.3f, range=[%.3f, %.3f]\n', ...
                mean(filtered_diameters), std(filtered_diameters), ...
                min(filtered_diameters), max(filtered_diameters));
    end
end

function diameter = calculateDiameterFromBorders(tree_center, binary_map, cell_size, R, C, Xmax, Ymax)
    %CALCULATEDIAMETERFROMBORDERS Calculate diameter from actual tree borders
    
    % Convert tree center to grid coordinates with bounds checking
    center_col = round(tree_center(1) / (Xmax / C)) + 1;
    center_row = round(R - tree_center(2) / (Ymax / R));
    
    % Ensure center is within bounds
    center_col = max(1, min(center_col, C));
    center_row = max(1, min(center_row, R));
    
    % Additional bounds check
    if center_row < 1 || center_row > R || center_col < 1 || center_col > C
        fprintf('  Border detection: center out of bounds, using fallback diameter\n');
        diameter = 0.35;
        return;
    end
    
    % Define search radius (should be larger than any expected tree)
    max_search_radius = round(1.0 / cell_size); % 1 meter search radius
    
    % Use region growing to find the connected tree component
    tree_mask = false(R, C);
    if binary_map(center_row, center_col) == 1
        % Start from occupied center
        tree_mask = floodFillTree(binary_map, center_row, center_col);
    else
        % Find nearest occupied cell if center is not occupied
        [occupied_rows, occupied_cols] = find(binary_map);
        if ~isempty(occupied_rows)
            distances = sqrt((occupied_rows - center_row).^2 + (occupied_cols - center_col).^2);
            [~, nearest_idx] = min(distances);
            if distances(nearest_idx) <= max_search_radius
                tree_mask = floodFillTree(binary_map, occupied_rows(nearest_idx), occupied_cols(nearest_idx));
            end
        end
    end
    
    % Extract border points from the tree mask
    if any(tree_mask(:))
        % Find boundary of the tree
        tree_boundary = bwboundaries(tree_mask, 'noholes');
        
        if ~isempty(tree_boundary)
            % Use the longest boundary (main tree outline)
            boundary_lengths = cellfun(@length, tree_boundary);
            [~, longest_idx] = max(boundary_lengths);
            border_points = tree_boundary{longest_idx};
            
            % Convert border points to world coordinates
            border_x = (border_points(:, 2) - 1) * (Xmax / C);
            border_y = Ymax - (border_points(:, 1) - 1) * (Ymax / R);
            
            % Calculate diameter using multiple methods
            diameter = calculateDiameterFromBoundary(border_x, border_y, tree_center);
            
            %fprintf('  Border detection: found %d border points -> diameter %.3f\n', length(border_points), diameter);
        else
            % Fallback if no boundary found
            diameter = 0.35;
            %fprintf('  Border detection: no boundary found, using fallback diameter %.3f\n', diameter);
        end
    else
        % Fallback if no tree mask found
        diameter = 0.35;
        %fprintf('  Border detection: no tree mask found, using fallback diameter %.3f\n', diameter);
    end
    
    % Ensure reasonable bounds
    diameter = max(0.15, min(diameter, 0.8));
end

function tree_mask = floodFillTree(binary_map, start_row, start_col)
    %FLOODFILLTREE Flood fill to find connected tree component
    
    [R, C] = size(binary_map);
    tree_mask = false(R, C);
    
    if start_row < 1 || start_row > R || start_col < 1 || start_col > C
        return;
    end
    
    if binary_map(start_row, start_col) == 0
        return;
    end
    
    % Use built-in flood fill
    tree_mask = binary_map;
    tree_mask = imfill(tree_mask, [start_row, start_col], 8);
    
    % Only keep the connected component containing the start point
    cc = bwconncomp(tree_mask, 8);
    for i = 1:cc.NumObjects
        [rows, cols] = ind2sub([R, C], cc.PixelIdxList{i});
        if any(rows == start_row & cols == start_col)
            temp_mask = false(R, C);
            temp_mask(cc.PixelIdxList{i}) = true;
            tree_mask = temp_mask;
            break;
        end
    end
end

function diameter = calculateDiameterFromBoundary(border_x, border_y, tree_center)
    %CALCULATEDIAMETERFROMBOUNDARY Calculate diameter from boundary points
    
    if length(border_x) < 3
        diameter = 0.35;
        return;
    end
    
    % Method 1: Maximum distance from center
    distances_from_center = sqrt((border_x - tree_center(1)).^2 + (border_y - tree_center(2)).^2);
    max_radius = max(distances_from_center);
    diameter_method1 = 2 * max_radius;
    
    % Method 2: Average distance from center (more robust)
    avg_radius = mean(distances_from_center);
    diameter_method2 = 2 * avg_radius;
    
    % Method 3: Fit circle to boundary points
    try
        % Use least squares circle fitting
        [center_fit, radius_fit] = fitCircle(border_x, border_y);
        diameter_method3 = 2 * radius_fit;
    catch
        diameter_method3 = diameter_method2;
    end
    
    % Method 4: Maximum distance between any two boundary points
    if length(border_x) < 100  % Only for small boundaries to avoid computational cost
        dist_matrix = pdist2([border_x, border_y], [border_x, border_y]);
        max_diameter = max(dist_matrix(:));
        diameter_method4 = max_diameter;
    else
        diameter_method4 = diameter_method1;
    end
    
    % Method 5: Equivalent diameter from area
    tree_area = polyarea(border_x, border_y);
    diameter_method5 = 2 * sqrt(tree_area / pi);
    
    % Combine methods (exclude obviously wrong values)
    methods = [diameter_method1, diameter_method2, diameter_method3, diameter_method4, diameter_method5];
    valid_methods = methods(methods > 0.1 & methods < 1.5);  % Reasonable range
    
    if ~isempty(valid_methods)
        diameter = median(valid_methods);
    else
        diameter = 0.35;
    end
    
    %fprintf('    Boundary methods: max_radius=%.3f, avg_radius=%.3f, circle_fit=%.3f, max_dist=%.3f, area=%.3f -> final=%.3f\n', diameter_method1, diameter_method2, diameter_method3, diameter_method4, diameter_method5, diameter);
end

function [center, radius] = fitCircle(x, y)
    %FITCIRCLE Fit a circle to 2D points using least squares
    
    % Remove duplicate points
    [~, unique_idx] = unique([x, y], 'rows');
    x = x(unique_idx);
    y = y(unique_idx);
    
    if length(x) < 3
        center = [mean(x), mean(y)];
        radius = 0.35;
        return;
    end
    
    % Set up least squares problem: (x-a)^2 + (y-b)^2 = r^2
    % Rearrange to: x^2 + y^2 - 2ax - 2by = r^2 - a^2 - b^2
    A = [-2*x, -2*y, ones(length(x), 1)];
    B = -(x.^2 + y.^2);
    
    % Solve least squares
    params = A \ B;
    
    center = [-params(1), -params(2)];
    radius = sqrt(params(3) + params(1)^2 + params(2)^2);
    
    % Sanity check
    if radius < 0.05 || radius > 1.0
        center = [mean(x), mean(y)];
        radius = std(sqrt((x - center(1)).^2 + (y - center(2)).^2));
    end
end

function groups = findConnectedComponents(adjacency)
    %FINDCONNECTEDCOMPONENTS Find connected components in adjacency matrix
    n = size(adjacency, 1);
    visited = false(n, 1);
    groups = {};
    
    for i = 1:n
        if ~visited(i)
            % Start new group with BFS
            group = [];
            queue = i;
            
            while ~isempty(queue)
                current = queue(1);
                queue(1) = [];
                
                if ~visited(current)
                    visited(current) = true;
                    group(end+1) = current;
                    
                    % Add neighbors to queue
                    neighbors = find(adjacency(current, :));
                    for neighbor = neighbors
                        if ~visited(neighbor)
                            queue(end+1) = neighbor;
                        end
                    end
                end
            end
            
            groups{end+1} = group;
        end
    end
end

function [error_stats] = calculateErrorHistograms(tree_locations, tree_diameters, ground_truth_trees)
    %CALCULATEERRORHISTOGRAMS Calculate error histograms and descriptive statistics
    
    fprintf('\n=== ERROR ANALYSIS AND HISTOGRAMS ===\n');
    
    true_locations = ground_truth_trees(:, 1:2);
    true_diameters = ground_truth_trees(:, 3);
    
    num_true = size(true_locations, 1);
    num_detected = size(tree_locations, 1);
    
    % Find matches between detected and ground truth trees
    match_threshold = 2.0; % meters
    matched_pairs = [];
    position_errors = [];
    diameter_errors = [];
    
    % For each detected tree, find closest ground truth
    for i = 1:num_detected
        distances = sqrt(sum((true_locations - tree_locations(i,:)).^2, 2));
        [min_dist, closest_idx] = min(distances);
        if min_dist < match_threshold
            matched_pairs(end+1, :) = [i, closest_idx];
            position_errors(end+1) = min_dist;
            diameter_errors(end+1) = tree_diameters(i) - true_diameters(closest_idx);
        end
    end
    
    % Calculate X and Y position errors separately
    x_errors = [];
    y_errors = [];
    for i = 1:size(matched_pairs, 1)
        det_idx = matched_pairs(i, 1);
        gt_idx = matched_pairs(i, 2);
        x_errors(end+1) = tree_locations(det_idx, 1) - true_locations(gt_idx, 1);
        y_errors(end+1) = tree_locations(det_idx, 2) - true_locations(gt_idx, 2);
    end
    
    % Create error histograms figure
    figure(3);
    set(gcf, 'Position', [150, 150, 1200, 800]);
    
    % Position error histogram
    subplot(2, 3, 1);
    if ~isempty(position_errors)
        histogram(position_errors, 'BinWidth', 0.1, 'FaceColor', 'blue', 'EdgeColor', 'black');
        xlabel('Position Error (m)');
        ylabel('Frequency');
        title('Position Error Distribution');
        grid on;
        calculateStats(position_errors, 'Position Error');
    end
    
    % X position error histogram
    subplot(2, 3, 2);
    if ~isempty(x_errors)
        histogram(x_errors, 'BinWidth', 0.1, 'FaceColor', 'red', 'EdgeColor', 'black');
        xlabel('X Position Error (m)');
        ylabel('Frequency');
        title('X Position Error Distribution');
        grid on;
        calculateStats(x_errors, 'X Position Error');
    end
    
    % Y position error histogram
    subplot(2, 3, 3);
    if ~isempty(y_errors)
        histogram(y_errors, 'BinWidth', 0.1, 'FaceColor', 'green', 'EdgeColor', 'black');
        xlabel('Y Position Error (m)');
        ylabel('Frequency');
        title('Y Position Error Distribution');
        grid on;
        calculateStats(y_errors, 'Y Position Error');
    end
    
    % Diameter error histogram
    subplot(2, 3, 4);
    if ~isempty(diameter_errors)
        histogram(diameter_errors, 'BinWidth', 0.02, 'FaceColor', 'magenta', 'EdgeColor', 'black');
        xlabel('Diameter Error (m)');
        ylabel('Frequency');
        title('Diameter Error Distribution');
        grid on;
        calculateStats(diameter_errors, 'Diameter Error');
    end
    
    % Absolute diameter error histogram
    subplot(2, 3, 5);
    if ~isempty(diameter_errors)
        abs_diameter_errors = abs(diameter_errors);
        histogram(abs_diameter_errors, 'BinWidth', 0.02, 'FaceColor', 'cyan', 'EdgeColor', 'black');
        xlabel('Absolute Diameter Error (m)');
        ylabel('Frequency');
        title('Absolute Diameter Error Distribution');
        grid on;
        calculateStats(abs_diameter_errors, 'Absolute Diameter Error');
    end
    
    % Summary subplot
    subplot(2, 3, 6);
    text(0.1, 0.9, sprintf('Total GT trees: %d', num_true), 'FontSize', 12);
    text(0.1, 0.8, sprintf('Detected trees: %d', num_detected), 'FontSize', 12);
    text(0.1, 0.7, sprintf('Matched pairs: %d', size(matched_pairs, 1)), 'FontSize', 12);
    text(0.1, 0.6, sprintf('Detection rate: %.1f%%', size(matched_pairs, 1) / num_true * 100), 'FontSize', 12);
    text(0.1, 0.5, sprintf('Precision: %.1f%%', size(matched_pairs, 1) / max(num_detected, 1) * 100), 'FontSize', 12);
    
    if ~isempty(position_errors)
        text(0.1, 0.3, sprintf('Avg pos error: %.3f m', mean(position_errors)), 'FontSize', 12);
    end
    if ~isempty(diameter_errors)
        text(0.1, 0.2, sprintf('Avg diam error: %.3f m', mean(abs(diameter_errors))), 'FontSize', 12);
    end
    
    set(gca, 'XTick', [], 'YTick', []);
    title('Summary Statistics');
    
    % Store results
    error_stats = struct();
    error_stats.num_matched = size(matched_pairs, 1);
    error_stats.num_true = num_true;
    error_stats.num_detected = num_detected;
    error_stats.detection_rate = size(matched_pairs, 1) / num_true * 100;
    error_stats.precision = size(matched_pairs, 1) / max(num_detected, 1) * 100;
end

function stats = calculateStats(data, data_name)
    %CALCULATESTATS Calculate descriptive statistics for error data
    
    if isempty(data)
        fprintf('%s: No data available\n', data_name);
        return;
    end
    
    % Calculate statistics
    stats.mean = mean(data);
    stats.std = std(data);
    stats.rms = sqrt(mean(data.^2));
    stats.min = min(data);
    stats.max = max(data);
    stats.percentile_95 = prctile(data, 95);
    stats.median = median(data);
    stats.count = length(data);
    
    % Print statistics
    fprintf('\n%s Statistics:\n', data_name);
    fprintf('  Count: %d\n', stats.count);
    fprintf('  Mean: %.4f\n', stats.mean);
    fprintf('  Std Dev: %.4f\n', stats.std);
    fprintf('  RMS: %.4f\n', stats.rms);
    fprintf('  Median: %.4f\n', stats.median);
    fprintf('  Min: %.4f\n', stats.min);
    fprintf('  Max: %.4f\n', stats.max);
    fprintf('  95th Percentile: %.4f\n', stats.percentile_95);
end

function generateOutputFile(tree_locations, tree_diameters, filename)
    %GENERATEOUTPUTFILE Generate output file with detected tree data
    
    fprintf('\n=== GENERATING OUTPUT FILE ===\n');
    
    % Open file for writing
    fid = fopen(filename, 'w');
    if fid == -1
        error('Could not open file %s for writing', filename);
    end
    
    % Write header comment
    fprintf(fid, '%% Detected Trees Output File\n');
    fprintf(fid, '%% Generated on: %s\n', datestr(now));
    fprintf(fid, '%% Format: Row_Number, X_Coordinate(m), Y_Coordinate(m), Diameter(m)\n');
    fprintf(fid, '%% Total trees detected: %d\n', length(tree_diameters));
    fprintf(fid, '%%\n');
    
    % Write tree data
    for i = 1:length(tree_diameters)
        fprintf(fid, '%d, %.4f, %.4f, %.4f\n', ...
                i, tree_locations(i, 1), tree_locations(i, 2), tree_diameters(i));
    end
    
    % Close file
    fclose(fid);
    
    fprintf('Output file saved as: %s\n', filename);
    fprintf('Format: Row number, X coordinate (m), Y coordinate (m), Diameter (m)\n');
    fprintf('Total trees written: %d\n', length(tree_diameters));
    
    % Display first few lines as preview
    fprintf('\nFile preview (first 5 trees):\n');
    fprintf('Row#, X(m), Y(m), D(m)\n');
    for i = 1:min(5, length(tree_diameters))
        fprintf('%d, %.4f, %.4f, %.4f\n', ...
                i, tree_locations(i, 1), tree_locations(i, 2), tree_diameters(i));
    end
    if length(tree_diameters) > 5
        fprintf('... (%d more trees)\n', length(tree_diameters) - 5);
    end
end